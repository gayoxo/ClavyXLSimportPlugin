#!/bin/bash
java -jar ClavyXLSImportPluginJSONGenerator.jar